# English

### Project 2 - My First Bootstrap 4 Page

<br/>

This project aims to build to make "My First Bootstrap 4 Page" that is at w3schools to improve knowledges about Bootstrap. Instead of looking codes through site , I taught the designing processes like any UI or UX developer gives us their designing files and we are going to decide build this page with Bootstrap as CSS framework.

Deployed at https://sahinmaral-myfirstbootstrap4page.netlify.app

<b>Click to picture to watch for understanding how to build </b>


<a href="https://www.youtube.com/watch?v=q_x8AHImoT0">
<img src="./thumbnail.webp"></img>
</a>


<br/>
<br/>
<br/>

# Türkçe

### Project 2 - My First Bootstrap 4 Page

<br/>

Bu projede amaç , Bootstrap üzerindeki bilgileri pekiştirme yapmak için w3Schools üzerinde yer alan My First Bootstrap 4 Page sayfasını yapabilmektir. Site üzerinden kodları incelemek yerine sanki bir UI veya UX tasarımcısı bize dizayn dosyalarını verip CSS framework olarak Bootstrap ile bu sayfayı yapmaya karar vermişiz gibi yapım aşamalarını anlattım.

https://sahinmaral-myfirstbootstrap4page.netlify.app sitesine deploy edilmiştir

<b> Nasıl yapıldığını anlamak için resme tıklayıp izleyebilirsiniz </b>

<a href="https://www.youtube.com/watch?v=q_x8AHImoT0">
<img src="./thumbnail.webp"></img>
</a>


